#import <UIKit/UIKit.h>
@interface RCTCameraFocusSquare : UIView
@end